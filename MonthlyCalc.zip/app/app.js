import Vue from 'nativescript-vue';

import MonthlyCalc from './components/MonthlyCalc';

// Uncommment the following to see NativeScript-Vue output logs
// Vue.config.silent = false;

new Vue({

    template: `
        <Frame>
            <MonthlyCalc />
        </Frame>`,

    components: {
        MonthlyCalc
    }
}).$start();