<template>
    <Page>
        <ActionBar title=" " flat="true"></ActionBar>

        <BottomNavigation>
            <TabStrip>
                <TabStripItem>
                    <Label text="Income"></Label>
                </TabStripItem>
                <TabStripItem>
                    <Label text="Expenditures"></Label>
                </TabStripItem>
                <TabStripItem>
                    <Label text="Results"></Label>
                </TabStripItem>
            </TabStrip>

            <TabContentItem>
                <StackLayout rows="auto, auto, *">
                    <Label row="0" class="ti" text="Income"></Label>
                    <TextField row="1" v-model="monthlyIncome"
                        hint="What is your monthly income?"
                        keyboardType="number"></TextField>
                </StackLayout>
            </TabContentItem>
            <TabContentItem>
                <StackLayout rows="auto, auto, *">
                    <Label row="0" class="ti" text="Expenditures"></Label>
                    <TextField row="1" v-model="monthlySpendingHousing"
                        hint="How much do you spend per month on housing?"
                        keyboardType="number">
                    </TextField>
                    <TextField row="2" v-model="monthlySpendingFood"
                        hint="How much do you spend per month on food?"
                        keyboardType="number">
                    </TextField>
                    <TextField row="3" v-model="monthlySpendingTransportation"
                        hint="How much do you spend per month on transportation?"
                        keyboardType="number">
                    </TextField>
                    <TextField row="4" v-model="monthlySpendingEducation"
                        hint="How much do you spend per month on education?"
                        keyboardType="number">
                    </TextField>
                    <TextField row="5" v-model="monthlySpendingMisc"
                        hint="How much do you spend per month on other miscellaneous expenses?"
                        keyboardType="number">
                    </TextField>
                </StackLayout>
            </TabContentItem>
            <TabContentItem>
                <GridLayout rows="auto, auto, *">
                    <Label row="0" class="ti" text="Results"></Label>
                    <Button text="View your results" row="2" class="button"
                        @tap="viewResults" />
                </GridLayout>
            </TabContentItem>
        </BottomNavigation>
    </Page>
</template>


<script>
    var numCorrect;
    numCorrect = 0;
    const dialogs = require("tns-core-modules/ui/dialogs");
    const appSettings = require("tns-core-modules/application-settings");
    export default {
        methods: {
            onButtonTap1() {
                this.numCorrect += 1;
                console.log(this.numCorrect);
            },
            saveSpending() {
                appSettings.clear("spending");
                appSettings.setNumber("spending", parseFloat(this
                    .monthlySpending));
                dialogs.alert("You spent: " + appSettings.getNumber(
                    "spending"));
            },
            saveIncome() {
                appSettings.clear("income");
                appSettings.setNumber("income", parseFloat(this
                    .monthlyIncome));
                dialogs.alert("You made: " + appSettings.getNumber("income"));
            },
            viewResults() {
                appSettings.clear("results");
                appSettings.setNumber(
                    "results",
                    parseFloat(this.monthlyIncome) -
                    parseFloat(this.monthlySpendingTransportation) -
                    parseFloat(this.monthlySpendingHousing) -
                    parseFloat(this.monthlySpendingEducation) -
                    parseFloat(this.monthlySpendingFood) -
                    parseFloat(this.monthlySpendingMisc)
                );
                appSettings.setNumber(
                    "propHousing",
                    (parseFloat(this.monthlySpendingHousing) * 100) /
                    parseFloat(this.monthlyIncome)
                );
                appSettings.setNumber(
                    "propTransportation",
                    (parseFloat(this.monthlySpendingTransportation) *
                    100) /
                    parseFloat(this.monthlyIncome)
                );
                appSettings.setNumber(
                    "propFood",
                    (parseFloat(this.monthlySpendingFood) * 100) /
                    parseFloat(this.monthlyIncome)
                );
                appSettings.setNumber(
                    "propEducation",
                    (parseFloat(this.monthlySpendingEducation) * 100) /
                    parseFloat(this.monthlyIncome)
                );
                appSettings.setNumber(
                    "propMisc",
                    (parseFloat(this.monthlySpendingMisc) * 100) /
                    parseFloat(this.monthlyIncome)
                );
                appSettings.setNumber(
                    "propSaved",
                    ((parseFloat(this.monthlyIncome) -
                            parseFloat(this
                            .monthlySpendingTransportation) -
                            parseFloat(this.monthlySpendingHousing) -
                            parseFloat(this.monthlySpendingEducation) -
                            parseFloat(this.monthlySpendingFood) -
                            parseFloat(this.monthlySpendingMisc)) *
                        100) /
                    parseFloat(this.monthlyIncome)
                );
                dialogs.alert(
                    "You saved $" +
                    appSettings.getNumber("results") +
                    " this month, spending " +
                    appSettings.getNumber("propHousing").toFixed(1) +
                    "% of your income on housing, " +
                    appSettings.getNumber("propTransportation").toFixed(
                    1) +
                    "% of your income on transportation, " +
                    appSettings.getNumber("propFood").toFixed(1) +
                    "% of your income on food, " +
                    appSettings.getNumber("propEducation").toFixed(1) +
                    "% of your income on education, and " +
                    appSettings.getNumber("propMisc").toFixed(1) +
                    "% of your income on miscellaneous expenses. You thus saved the remaining " +
                    appSettings.getNumber("propSaved").toFixed(1) + "% of your income."
                );
            }
        },

        data() {
            return {
                textFieldValue: ""
            };
        }
    };
</script>

<style scoped>
    .home-panel {
        vertical-align: center;
        font-size: 20;
        margin: 15;
    }

    .description-label {
        margin-bottom: 15;
    }

    .button {
        background-color: darkgreen;
        color: white;
        margin-top: 0;
    }

    .ti {
        vertical-align: center;
        background-color: #35495E;
        color: white;
        font-size: 34;
        font-weight: 600;
        padding: 0;
        margin-top: 5;
    }
</style>